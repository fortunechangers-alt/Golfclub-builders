        </main>
    </div>
    
    <script src="<?= base_url('js/main.js') ?>"></script>
    <?php if (isset($additionalScripts)): ?>
        <?= $additionalScripts ?>
    <?php endif; ?>
</body>
</html>

